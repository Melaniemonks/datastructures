**Melanie Monkurai (Data Structure Tutorials)**

Interested in Python Data Structures! Start here
- [Sets](setsTutorial.md)

**Additional information**
Professor: Bro Kelly Tucker

Course: CSE212
