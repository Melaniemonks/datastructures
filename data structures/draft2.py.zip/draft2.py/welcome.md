**Melanie Monkurai (Data Structure Tutorials)**

Interested in Python Data Structures! Start here
- [Queues](queuesTutorial.md)

**Additional information**
Professor: Bro Kelly Tucker

Course: CSE212
